package Aircrafts;
public class WWIIAirplane extends Aircraft{
	protected boolean twinEng;
	
	public WWIIAirplane() {
		super();
		this.twinEng=true;
	}
	public WWIIAirplane(double price,double maxElevation,boolean twinEng) {
		super(price,maxElevation);
		this.twinEng = twinEng;
	}
	public void copy(WWIIAirplane obj) {
		super.copy(obj);
		this.twinEng = obj.twinEng;
	}
	public boolean getEng() {
		return twinEng;
	}
	public String toString() {
		if (twinEng==true) {
			return ("This aircraft has a price of "+price+" and a max elevation of "+maxElevation+"."
					+ "It has a twin engine");
		}
		else {
			return ("This aircraft has a price of "+price+" and a max elevation of "+maxElevation+"."
					+ "It does not have a twin engine");
		}
	}
	public boolean equals(Object obj) {
		boolean equal = true;
		if (obj==null) {
			equal = false;
		}
		else if (obj instanceof WWIIAirplane) {
			WWIIAirplane obj1 = (WWIIAirplane)obj;
			if (this.price != obj1.getPrice())
				equal = false;
			if (this.maxElevation != obj1.getElevation()) 
				equal = false;
			if (this.twinEng != obj1.getEng()) {
				}

				
		
		}
		else equal = false;
		return equal;
	}
}
