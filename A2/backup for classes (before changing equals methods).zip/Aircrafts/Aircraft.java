package Aircrafts;

import Ferry.Ferry;

public class Aircraft {
	protected double price;
	protected double maxElevation;
	
	public Aircraft() {
		price = 10;
		maxElevation = 1000;
	}
	public Aircraft(double price,double maxElevation) {
		this.price=price;
		this.maxElevation = maxElevation;
	}
	public void copy(Aircraft obj) {
		this.price = obj.price;
		this.maxElevation = obj.maxElevation;
	}
	public double getPrice() {
		return price;
	}
	public double getElevation() {
		return maxElevation;
	}
	public String toString() {
		return ("This aircraft has a price of "+price+" and a max elevation of "+maxElevation+".");
	}
	public boolean equals(Object obj) {
		boolean equal = true;
		if (obj==null) {
			equal = false;
		}
		else if (obj instanceof Aircraft) {
			Aircraft obj1 = (Aircraft)obj;
			if (this.price != obj1.getPrice())
				equal = false;
			if (this.maxElevation != obj1.getElevation()) 
				equal = false;
				
		
		}
		else equal = false;
		return equal;
	}
}
