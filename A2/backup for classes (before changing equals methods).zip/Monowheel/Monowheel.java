package Monowheel;
import WheeledTransportation.*;

public class Monowheel extends WheeledTransportation{
	protected double maxWeight;
	
	public Monowheel() {
		super();
		this.maxWeight = 100;
	}
	public Monowheel(int nbOfWheels,double maxSpeed,double maxWeight) {
		super(nbOfWheels,maxSpeed);
		this.maxWeight = maxWeight;
	}
	public void copy(Monowheel obj) {
		super.copy(obj);
		this.maxWeight = obj.maxWeight;
	}
	public double getWeight() {
		return maxWeight;
	}
	public String toString() {
		return ("This monowheel has "+nbOfWheels+" wheels and has a maximum speed of "+maxSpeed+"."
				+ "It has a max weight of "+maxWeight+".");
	}
	public boolean equals(Object obj) {
		boolean equal = true;
		if (obj==null) {
			equal = false;
		}
		else if (obj instanceof Monowheel) {
			Monowheel obj1 = (Monowheel)obj;
			if (this.nbOfWheels != obj1.getWheels())
				equal = false;
			if (this.maxSpeed != obj1.getSpeed()) 
				equal = false;
			if (this.maxWeight != obj1.getWeight()) 
				equal = false;
		
		}
		else equal = false;
		return equal;
	}
}