package Metro;
import Train_Tram.Train;

public class Metro extends Train{
	protected int nbStops;
	
	public Metro() {
		super();
		nbStops = 1;
	}
	public Metro(int nbOfWheels,double maxSpeed,int nbVehicles,String startStation,String destStation,int nbStops) {
		super(nbOfWheels,maxSpeed,nbVehicles,startStation,destStation);
		this.nbStops = nbStops;
	}
	public void copy(Metro obj) {
		super.copy(obj);
		this.nbStops = obj.nbStops;
	}
	public int getStops() {
		return nbStops;
	}
	public String toString() {
		return ("This metro has "+nbOfWheels+" wheels and has a max speed of "+maxSpeed+". "
				+ "\nIt has "+nbVehicles+" vehicles and its starting and destination stations are "+startStation+" and "+destStation
				+ "\nIt has "+nbStops+" stops.");
	}
	public boolean equals(Object obj) {
		boolean equal = true;
		if (obj==null) {
			equal = false;
		}
		else if (obj instanceof Metro) {
			Metro obj1 = (Metro)obj;
			if (this.nbOfWheels != obj1.getWheels())
				equal = false;
			if (this.maxSpeed != obj1.getSpeed()) 
				equal = false;
			if (this.nbVehicles != obj1.getVehicles())
				equal = false;
			if (this.startStation != obj1.getStart())
				equal = false;
			if (this.destStation != obj1.getDest())
				equal = false;
			if (this.nbStops != obj1.getStops())
				equal = false;
				
		
		}
		else equal = false;
		return equal;
	}
}
