package Train_Tram;
import Metro.Metro;
import Object2.*;
public class Tram extends Metro{
	protected int creationYr;
	
	public Tram() {
		super();
		this.creationYr = 2000;
	}
	public Tram(int nbOfWheels,double maxSpeed,int nbVehicles,String startStation,String destStation,int nbStops,int creationYr) {
		super(nbOfWheels,maxSpeed,nbVehicles,startStation,destStation,nbStops);
		this.creationYr = creationYr;
	}
	public Object2 copy(Object2 obj) {
		Tram t = new Tram();
		t = (Tram) super.copy(t);
		t.creationYr = this.creationYr;
		return t;
	}
	public int getCreat() {
		return creationYr;
	}
	public String toString() {
		return ("This tram has "+nbOfWheels+" wheels and has a max speed of "+maxSpeed+". "
				+ "\nIt has "+nbVehicles+" vehicles and its starting and destination stations are "+startStation+" and "+destStation+"."
				+ "\nIt has "+nbStops+" stops."
				+ "\nThe creation year of this tram is "+creationYr+".");
	}
	public boolean equals(Object obj) {
		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			Tram obj1 = (Tram)obj;
			if (this.nbOfWheels != obj1.nbOfWheels)
				return false;
			if (this.maxSpeed != obj1.maxSpeed) 
				return false;
			if (this.nbVehicles != obj1.nbVehicles)
				return false;
			if (this.startStation != obj1.startStation)
				return false;
			if (this.destStation != obj1.destStation)
				return false;
			if (this.nbStops != obj1.nbStops)
				return false;
			if (this.creationYr != obj1.creationYr)
				return false;
			else return true;
				
		
		}
		else return false;
	}
}
