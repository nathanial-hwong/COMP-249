package Aircrafts;
import Object2.*;
import Ferry.Ferry;

public class Aircraft extends Object2{
	protected double price;
	protected double maxElevation;
	
	public Aircraft() {
		price = 10;
		maxElevation = 1000;
	}
	public Aircraft(double price,double maxElevation) {
		this.price=price;
		this.maxElevation = maxElevation;
	}
	public Object2 copy(Object2 obj) {
		Aircraft a = new Aircraft();
		a.price = this.price;
		a.maxElevation = this.maxElevation;
		return a;
	}
	public double getPrice() {
		return price;
	}
	public double getElevation() {
		return maxElevation;
	}
	public String toString() {
		return ("This aircraft has a price of "+price+" and a max elevation of "+maxElevation+".");
	}
	public boolean equals(Object obj) {

		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			Aircraft obj1 = (Aircraft)obj;
			if (this.price != obj1.price)
				return false;
			if (this.maxElevation != obj1.maxElevation) 
				return false;
			else return true;
				
		
		}
		else return false;

	}
}
