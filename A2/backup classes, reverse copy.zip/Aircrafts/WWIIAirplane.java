package Aircrafts;
import Object2.*;
public class WWIIAirplane extends Aircraft{
	protected boolean twinEng;
	
	public WWIIAirplane() {
		super();
		this.twinEng=true;
	}
	public WWIIAirplane(double price,double maxElevation,boolean twinEng) {
		super(price,maxElevation);
		this.twinEng = twinEng;
	}
	public Object2 copy(Object2 obj) {
		WWIIAirplane w = new WWIIAirplane();
		w = (WWIIAirplane) super.copy(w);
		w.twinEng = this.twinEng;
		return w;
	}
	public boolean getEng() {
		return twinEng;
	}
	public String toString() {
		if (twinEng==true) {
			return ("This aircraft has a price of "+price+" and a max elevation of "+maxElevation+"."
					+ "It has a twin engine");
		}
		else {
			return ("This aircraft has a price of "+price+" and a max elevation of "+maxElevation+"."
					+ "It does not have a twin engine");
		}
	}
	public boolean equals(Object obj) {
		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			WWIIAirplane obj1 = (WWIIAirplane)obj;
			if (this.price != obj1.price)
				return false;
			if (this.maxElevation != obj1.maxElevation) 
				return false;
			if (this.twinEng != obj1.twinEng)
				return false;
			else return true;

				
		
		}
		else return false;
	}
}
