package Object2;

public class Object2 {
	
	public Object2() {
		 
	}
	public Object2 copy(Object2 obj) {
		return obj;
	}
}
