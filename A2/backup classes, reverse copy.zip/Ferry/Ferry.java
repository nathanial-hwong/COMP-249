package Ferry;
import Object2.*;
public class Ferry extends Object2{
	protected double maxSpeed;
	protected double maxLoad;
	
	public Ferry(){
		
	}
	public Ferry(double maxSpeed,double maxLoad) {
		
	}
	public Object2 copy(Object2 obj) {
		Ferry f = new Ferry();
		f.maxSpeed = this.maxSpeed;
		f.maxLoad = this.maxLoad;
		return f;
	}
	public double getSpeed() {
		return maxSpeed;
	}
	public double getLoad() {
		return maxLoad;
	}
	public String toString() {
		return ("This ferry has a max speed of "+maxSpeed+" and a max load of "+maxLoad+".");
	}
	public boolean equals(Object obj) {
		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			Ferry obj1 = (Ferry)obj;
			if (this.maxLoad != obj1.maxLoad)
				return false;
			if (this.maxSpeed != obj1.maxSpeed) 
				return false;
			else return true;
				
		
		}
		else return false;
	}
}
