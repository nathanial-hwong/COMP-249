package Monowheel;
import WheeledTransportation.*;
import Object2.*;
public class Monowheel extends WheeledTransportation{
	protected double maxWeight;
	
	public Monowheel() {
		super();
		this.nbOfWheels = 1;
		this.maxWeight = 100;
	}
	public Monowheel(int nbOfWheels,double maxSpeed,double maxWeight) {
		super(nbOfWheels,maxSpeed);
		this.maxWeight = maxWeight;
	}
	public Object2 copy(Object2 obj) {
		Monowheel m = new Monowheel();
		m = (Monowheel) super.copy(m);
		m.maxWeight = this.maxWeight;
		return m;
	}
	public double getWeight() {
		return maxWeight;
	}
	public String toString() {
		return ("This monowheel has "+nbOfWheels+" wheels and has a maximum speed of "+maxSpeed+"."
				+ "It has a max weight of "+maxWeight+".");
	}
	public boolean equals(Object obj) {
		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			Monowheel obj1 = (Monowheel)obj;
			if (this.nbOfWheels != obj1.nbOfWheels)
				return false;
			if (this.maxSpeed != obj1.maxSpeed) 
				return false;
			if (this.maxWeight != obj1.maxWeight) 
				return false;
			else return true;
		
		}
		else return false;
	}
}