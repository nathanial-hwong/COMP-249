package WheeledTransportation;
import Object2.*;
public class WheeledTransportation extends Object2{
	protected int nbOfWheels;
	protected double maxSpeed;
	
	public WheeledTransportation() {
		nbOfWheels = 4;
		maxSpeed = 100;
	}
	public WheeledTransportation(int nbOfWheels,double maxSpeed) {
		this.nbOfWheels = nbOfWheels;
		this.maxSpeed = maxSpeed;
	}
	public Object2 copy(Object2 obj) {
		WheeledTransportation w = new WheeledTransportation();
		w.nbOfWheels = this.nbOfWheels;
		w.maxSpeed = this.maxSpeed;
		return w;
	}
	public int getWheels() {
		return nbOfWheels;
	}
	public double getSpeed() {
		return maxSpeed;
	}
	public String toString() {
		return ("This wheeled transportation has "+nbOfWheels+" wheels and has a maximum speed of "+maxSpeed+".");
	}
	public boolean equals(Object obj) {

		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			WheeledTransportation obj1 = (WheeledTransportation)obj;
			if (this.nbOfWheels != obj1.nbOfWheels)
				return false;
			if (this.maxSpeed != obj1.maxSpeed) 
				return false;
			else
				return true;
				
		
		}
		else return false;

	}
}
