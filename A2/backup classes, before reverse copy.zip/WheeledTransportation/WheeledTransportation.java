package WheeledTransportation;

public class WheeledTransportation {
	protected int nbOfWheels;
	protected double maxSpeed;
	
	public WheeledTransportation() {
		nbOfWheels = 4;
		maxSpeed = 100;
	}
	public WheeledTransportation(int nbOfWheels,double maxSpeed) {
		this.nbOfWheels = nbOfWheels;
		this.maxSpeed = maxSpeed;
	}
	public void copy(WheeledTransportation obj) {
		this.nbOfWheels = obj.nbOfWheels;
		this.maxSpeed = obj.maxSpeed;
	}
	public int getWheels() {
		return nbOfWheels;
	}
	public double getSpeed() {
		return maxSpeed;
	}
	public String toString() {
		return ("This wheeled transportation has "+nbOfWheels+" wheels and has a maximum speed of "+maxSpeed+".");
	}
	public boolean equals(Object obj) {

		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			WheeledTransportation obj1 = (WheeledTransportation)obj;
			if (this.nbOfWheels != obj1.nbOfWheels)
				return false;
			if (this.maxSpeed != obj1.maxSpeed) 
				return false;
			else
				return true;
				
		
		}
		else return false;

	}
}
