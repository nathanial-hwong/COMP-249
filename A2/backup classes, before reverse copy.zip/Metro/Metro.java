package Metro;
import Train_Tram.Train;

public class Metro extends Train{
	protected int nbStops;
	
	public Metro() {
		super();
		nbStops = 1;
	}
	public Metro(int nbOfWheels,double maxSpeed,int nbVehicles,String startStation,String destStation,int nbStops) {
		super(nbOfWheels,maxSpeed,nbVehicles,startStation,destStation);
		this.nbStops = nbStops;
	}
	public void copy(Metro obj) {
		super.copy(obj);
		this.nbStops = obj.nbStops;
	}
	public int getStops() {
		return nbStops;
	}
	public String toString() {
		return ("This metro has "+nbOfWheels+" wheels and has a max speed of "+maxSpeed+". "
				+ "\nIt has "+nbVehicles+" vehicles and its starting and destination stations are "+startStation+" and "+destStation
				+ "\nIt has "+nbStops+" stops.");
	}
	public boolean equals(Object obj) {
		
		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			Metro obj1 = (Metro)obj;
			if (this.nbOfWheels != obj1.nbOfWheels)
				return false;
			if (this.maxSpeed != obj1.maxSpeed) 
				return false;
			if (this.nbVehicles != obj1.nbVehicles)
				return false;
			if (this.startStation != obj1.startStation)
				return false;
			if (this.destStation != obj1.destStation)
				return false;
			if (this.nbStops != obj1.nbStops)
				return false;
			else return true;
		
		}
		else return false;

	}
}
