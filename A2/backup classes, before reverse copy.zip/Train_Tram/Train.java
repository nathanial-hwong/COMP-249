package Train_Tram;
import WheeledTransportation.WheeledTransportation;

public class Train extends WheeledTransportation{
	protected int nbVehicles;
	protected String startStation;
	protected String destStation;
	
	public Train() {
		super();
		this.nbVehicles = 2;
	}
	public Train(int nbOfWheels,double maxSpeed,int nbVehicles,String startStation,String destStation) {
		super(nbOfWheels,maxSpeed);
		this.nbVehicles = nbVehicles;
		this.startStation = startStation;
		this.destStation = destStation;
	}
	public void copy(Train obj) {
		super.copy(obj);
		this.nbVehicles = obj.nbVehicles;
		this.startStation = obj.startStation;
		this.destStation = obj.destStation;
		
	}
	public int getVehicles() {
		return nbVehicles;
	}
	public String getStart() {
		return startStation;
	}
	public String getDest() {
		return destStation;
	}
	public String toString() {
		return ("This train has "+nbOfWheels+" wheels and has a max speed of "+maxSpeed+". "
				+ "It has "+nbVehicles+" vehicles and its starting and destination stations are "+startStation+" and "+destStation);
	}
	public boolean equals(Object obj) {
		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			Train obj1 = (Train)obj;
			if (this.nbOfWheels != obj1.nbOfWheels)
				return false;
			if (this.maxSpeed != obj1.maxSpeed) 
				return false;
			if (this.nbVehicles != obj1.nbVehicles)
				return false;
			if (this.startStation != obj1.startStation)
				return false;
			if (this.destStation != obj1.destStation)
				return false;
			else return true;
				
		
		}
		else return false;
		
	}
}
