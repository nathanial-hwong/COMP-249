package Ferry;

import WheeledTransportation.WheeledTransportation;

public class Ferry {
	protected double maxSpeed;
	protected double maxLoad;
	
	public Ferry(){
		
	}
	public Ferry(double maxSpeed,double maxLoad) {
		
	}
	public void copy(Ferry obj) {
		this.maxSpeed = obj.maxSpeed;
		this.maxLoad = obj.maxLoad;
	}
	public double getSpeed() {
		return maxSpeed;
	}
	public double getLoad() {
		return maxLoad;
	}
	public String toString() {
		return ("This ferry has a max speed of "+maxSpeed+" and a max load of "+maxLoad+".");
	}
	public boolean equals(Object obj) {
		if (obj==null) {
			return false;
		}
		else if (obj.getClass()==this.getClass()) {
			Ferry obj1 = (Ferry)obj;
			if (this.maxLoad != obj1.maxLoad)
				return false;
			if (this.maxSpeed != obj1.maxSpeed) 
				return false;
			else return true;
				
		
		}
		else return false;
	}
}
